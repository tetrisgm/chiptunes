// CodeMirror supplies editing and compiler-derived visual feedback only. The
// host's restricted parser handles draft previews and explicit Run/Apply.
import { EditorView, basicSetup } from 'codemirror';
import { Decoration } from '@codemirror/view';
import { EditorState, StateEffect, StateField, Transaction } from '@codemirror/state';
import { isolateHistory } from '@codemirror/commands';
import { javascript } from '@codemirror/lang-javascript';
import { autocompletion } from '@codemirror/autocomplete';
import { setDiagnostics } from '@codemirror/lint';
import { inlineRolls } from './music-inline-rolls.mjs';
import { sourceControls } from './music-source-controls.mjs';

const help = {
  song: 'song({tempo:128,bars:16}) — finite song settings; bars are zero indexed.',
  pattern: 'pattern("name", notes("C2 . G2 .").stepsPerBar(8).gate(0.7))',
  notes: 'notes("C4 . E4 G4") — pitches and dot rests, in written order.',
  cycleV1: 'cycleV1("<C4 E4> [G4 B4] E4 ~") — one cycle = one four-beat bar in Chiptunes. Equal slots; [subdivisions], <alternation>, ~ rests, *2 repeats, C2(3,8,1) Euclidean hits/slots/left rotation. This bounded dialect is inspired by Tidal, not Tidal-compatible.',
  fast: 'fast(2) — run the preceding cycle expression twice as fast (integer 1–16); alternation follows transformed time.',
  slow: 'slow(2) — stretch the preceding cycle expression (integer 1–16). play repeat still counts output cycles, not complete slowed phrases.',
  rev: 'rev() — reverse within each cycle. A note crossing that cycle is rejected: put rev before slow for held notes.',
  every: 'every(4,"rev",3) — reverse zero-based cycles 3, 7, …; explicit offset 0–period−1, period 1–64. Rhythmic chains act in written order.',
  track: 'track("bass").instrument(0).play("name", {atBar:0,repeat:4})',
  event: 'event({ch:0,frame:0,frames:60,midi:60,inst:0,vel:0.8}) — exact frames.',
  instruments: 'instruments([...]) — explicit instrument register records.',
  waves: 'waves([...]) — explicit waveform assets.',
  performance: 'performance({...}) — explicit remaining performance/bank metadata; never packed code.',
  automation: 'automation({f:0,r:36,v:119}) — exact frame/register/value.',
  vibratoOff: 'vibratoOff({f:0,ch:0}) — disable driver vibrato.',
  waveLoad: 'waveLoad({f:0,slot:0}) — load a wave frame.',
  kit: 'kit({f:0,id:1}) — sample hit from the bundled kit bank.',
  transpose: 'transpose(semitones) — applies in source order.',
  register: 'register(octave) — moves pitch classes into the named scientific octave, in source order.',
  velocity: 'velocity(value) — replace token velocities with a value from 0 to 1.',
  gate: 'gate(fraction) — note length relative to its step. For cycleV1, applied after rhythmic transforms; the last gate wins.',
  stepsPerBar: 'stepsPerBar(count) — notes() resolution; not available on cycleV1().',
  play: 'play("pattern", {atBar:0,repeat:1}) — finite arrangement. notes repeats the whole phrase. cycleV1 selects onsets in [atBar, atBar+repeat), with song-global phase and untrimmed note tails. No infinite repeats.',
  instrument: 'instrument(index) — select an instrument in this song bank.'
};
const visualHelp = {
  visual:'visual({background:"#090615",palette:["#84f3d5","#b089ff"],feedback:0.84,seed:17});',
  control:'control("motion",{label:"Motion",min:0,max:2,step:0.01,value:0.8}); — named saved value, separate from source.',
  layer:'layer("tunnel",{count:24,speed:param("motion"),react:signal("bass.hit")}); — tunnel, tiles, orbits, ribbons, sparks.',
  param:'param("motion") — read a declared control; sliders do not rewrite code.',
  signal:'signal("drums.hit",1,0) — audio.bass/mid/treble/level; beat.phase/bar.phase; lead/counter/bass.hit or .pitch; drums.hit.'
};
const theme = EditorView.theme({
  '&': {height:'100%',backgroundColor:'#10121b',color:'#e7eaf4',fontSize:'14px'},
  '.cm-scroller': {overflow:'auto',fontFamily:'ui-monospace, SFMono-Regular, monospace'},
  '.cm-content': {caretColor:'#b9d968',minHeight:'240px'},
  '.cm-gutters': {backgroundColor:'#141723',color:'#929bb4',border:'0'},
  '.cm-activeLine,.cm-activeLineGutter': {backgroundColor:'#ffffff08'},
  '.cm-selectionBackground,&.cm-focused .cm-selectionBackground': {backgroundColor:'#58734466'},
  '.cm-tooltip': {backgroundColor:'#252b3d',color:'#fff',border:'1px solid #596175'},
  '.cm-music-sounding': {backgroundColor:'#b9d96824',boxShadow:'inset 0 -2px #b9d968',borderRadius:'2px'},
}, {dark:true});

// Playback is a view decoration, never an edit or an undo transaction. Draft
// changes clear highlights until the host can map the sounding source exactly.
const soundingEffect = StateEffect.define();
const soundingField = StateField.define({
  create: () => Decoration.none,
  update(value, transaction) {
    if (transaction.docChanged) return Decoration.none;
    for (const effect of transaction.effects) if (effect.is(soundingEffect)) {
      const length=transaction.newDoc.length;
      const ranges=effect.value.filter(s=>Number.isInteger(s.from)&&Number.isInteger(s.to)&&s.from>=0&&s.to>s.from&&s.to<=length)
        .map(s=>Decoration.mark({class:'cm-music-sounding'}).range(s.from,s.to));
      return Decoration.set(ranges,true);
    }
    return value;
  },
  provide: field => EditorView.decorations.from(field)
});

globalThis.CT_MUSIC_CODE_EDITOR = {
  help,
  mount(parent, source, onChange, {onSelectionChange,onNoteSelect,dialect,onLimit} = {}) {
    const visual=dialect==='visual',completionHelp=visual?visualHelp:help;
    const rolls=visual?{extensions:[],attach(){},destroy(){},setContext(){},setPlayback(){}}:inlineRolls({onNoteSelect});
    const controls=visual?{extensions:[],attach(){},destroy(){},setContext(){},cancelGesture(){}}:sourceControls();
    const view = new EditorView({doc:source,parent,extensions:[
      basicSetup, javascript(), theme, soundingField, rolls.extensions, controls.extensions, EditorView.lineWrapping,
      EditorView.contentAttributes.of({'aria-label':visual?'Visual source code':'Musical source code','data-shortcuts-off':''}),
      ...(visual?[EditorState.transactionFilter.of(tr=>{
        if(tr.newDoc.length<=32768)return tr;
        if(onLimit)onLimit('Visual code is limited to 32 KiB; this edit was not inserted.');
        return [];
      })]:[]),
      autocompletion({override:[ctx=>{
        const word=ctx.matchBefore(/\w*/);
        if (!word || (!ctx.explicit && word.from===word.to)) return null;
        return {from:word.from,options:Object.keys(completionHelp).map(label=>({label,type:'function',info:completionHelp[label]}))};
      }]}),
      EditorView.updateListener.of(update=>{
        if(update.docChanged) {
          controls.setContext(null);
          onChange(update.state.doc.toString());
        }
        if((update.selectionSet||update.docChanged)&&typeof onSelectionChange==='function')
          onSelectionChange(update.state.selection.ranges.map(r=>({from:r.from,to:r.to})));
      })
    ]});
    rolls.attach(view);controls.attach(view);
    let destroyed=false;
    const effects={diagnostics:0,sounding:0};
    function publish(kind,make){
      const doc=view.state.doc,ticket=++effects[kind];
      // The host may report diagnostics/highlights from its own onChange.
      // Never dispatch reentrantly, or decorate a different/newer document.
      queueMicrotask(()=>{
        if(!destroyed&&ticket===effects[kind]&&view.state.doc===doc)view.dispatch(make());
      });
    }
    return {
      value:()=>view.state.doc.toString(),
      selection:()=>view.state.selection.ranges.map(r=>({from:r.from,to:r.to})),
      set(source) { if(source!==view.state.doc.toString()) view.dispatch({changes:{from:0,to:view.state.doc.length,insert:source}}); },
      replaceDraft(source) {
        controls.cancelGesture();
        if(source!==view.state.doc.toString()) view.dispatch({
          changes:{from:0,to:view.state.doc.length,insert:source},selection:{anchor:0},scrollIntoView:true,
          annotations:[Transaction.userEvent.of('input.replace'),isolateHistory.of('full')]
        });
        view.focus();
      },
      select(from,to=from) {
        from=Math.max(0,Math.min(view.state.doc.length,from||0)); to=Math.max(from,Math.min(view.state.doc.length,to||from));
        view.dispatch({selection:{anchor:from,head:to},scrollIntoView:true}); view.focus();
      },
      diagnostics(items=[]) {
        const data=items.map(d=>({
          from:Math.max(0,Math.min(view.state.doc.length,d.from||0)),
          to:Math.max(0,Math.min(view.state.doc.length,d.to||d.from||0)),
          severity:d.severity==='warning'?'warning':'error',message:d.message||String(d)
        }));
        publish('diagnostics',()=>setDiagnostics(view.state,data));
      },
      highlightPlaying(spans=[]) {
        const data=spans.slice(0,4).map(s=>({from:s.from,to:s.to}));
        publish('sounding',()=>({effects:soundingEffect.of(data)}));
      },
      setPatternContext(context) {
        controls.setContext(context&&context.projectId!=null?context:null);
        return rolls.setContext(context);
      },
      setPatternPlayback:state=>rolls.setPlayback(state),
      cancelSourceGesture:()=>controls.cancelGesture(),
      destroy:()=>{destroyed=true;rolls.destroy();controls.destroy();view.destroy();}, focus:()=>view.focus()
    };
  }
};
