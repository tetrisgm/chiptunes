'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),os=require('node:os');
const {chromium}=require('playwright');
const root=path.join(__dirname,'../dist');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'chiptunes-workspace-'));
async function fixtureChatAccess(target){
  // Explicit owner-session fixture, never a production auth bypass.
  await target.route('**/api/music/chat/access',async route=>{
    assert.equal(route.request().method(),'GET');
    await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({ok:true,authenticated:true,
      providers:[{id:'openai',label:'OpenAI'}],limits:{dailyCalls:20}})});
  });
}
const server=http.createServer((req,res)=>{
  let file=path.join(root,new URL(req.url,'http://local').pathname);
  if(!file.startsWith(root)||!fs.existsSync(file)||fs.statSync(file).isDirectory())file=path.join(root,'index.html');
  res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(fs.readFileSync(file));
});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,args:['--autoplay-policy=no-user-gesture-required']});
 try{
  const context=await browser.newContext({viewport:{width:1800,height:900},acceptDownloads:true,permissions:['clipboard-read','clipboard-write']});
  await fixtureChatAccess(context);
  const page=await context.newPage(),errors=[];
  page.on('pageerror',e=>{errors.push(e.message);console.error('browser:',e.message);});
  await page.addInitScript(()=>localStorage.setItem('ct-create-tour','1'));
  await page.goto('http://127.0.0.1:'+server.address().port+'/create');
  await page.waitForSelector('#musicworkspace .cm-content',{state:'attached'});
  let initial=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  assert(initial.validated&&initial.validated.compiled.gb.notes.length>0,'starter code compiles into actual notes');
  assert(initial.draft.includes('pattern('),'fresh entry offers readable musical code');
  assert.equal(initial.playing,null,'opening workspace does not claim playback');
  await page.evaluate(()=>{const composer=CT_COMPOSERS.rrr_core,original=composer.compile;window.__workspaceCompositions=0;composer.compile=function(...args){window.__workspaceCompositions++;return original.apply(this,args);};});
  await page.locator('.mw-project-tools > summary').click();await page.locator('.mw-generate > summary').click();
  await page.locator('.mw-generate-text').fill('Make something happy');
  await page.click('#musicworkspace [data-action=generate]');
  await page.waitForFunction(()=>document.querySelector('.mw-status').textContent.startsWith('Generated once.'));
  assert.equal(await page.evaluate(()=>window.__workspaceCompositions),1,'prompt composes once');
  initial=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  await page.waitForTimeout(400);
  const provenance=await page.evaluate(()=>JSON.parse(localStorage.getItem('ct-music-workspace-v1')).private.provenance);
  assert.equal(provenance.prompt,'Make something happy');assert(provenance.seed,'explicit generation seed is recorded');
  await page.click('#musicworkspace .cm-content');
  await page.locator('.cm-content').fill('song({tempo:128,bars:2})\n\n// unfinished draft\ninvalid(');
  await page.click('#musicworkspace [data-action=apply]');
  const invalid=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  assert.equal(invalid.validated.id,initial.validated.id,'invalid draft keeps validated score');
  assert.match(await page.locator('.mw-diagnostics').textContent(),/error/,'diagnostics shown');
  await page.locator('.cm-content').press('Control+Space');
  await page.waitForSelector('.cm-tooltip-autocomplete');
  await page.locator('.cm-content').press('Escape');
  assert(await page.evaluate(()=>CT_MUSIC_WORKSPACE.isOpen()),'Escape dismisses completion before the workspace');
  await page.waitForTimeout(400);
  const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('ct-music-workspace-v1')));
  assert(saved.draft.endsWith('invalid('),'invalid draft recovered as exact text');
  assert(saved.lastValid,'last validated revision saved atomically');
  await page.reload();
  await page.waitForSelector('#musicworkspace:not([hidden])');
  await page.waitForSelector('#musicworkspace .cm-content',{state:'attached'});
  const recovered=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  assert.equal(recovered.draft,invalid.draft,'reload restores unfinished source rather than replacing it with a generated song');
  assert.deepEqual(recovered.validated.compiled.gb,initial.validated.compiled.gb);
  await page.click('#musicworkspace .cm-content');
  await page.locator('.cm-content').press('ControlOrMeta+a');
  await page.evaluate(text=>navigator.clipboard.writeText(text),initial.draft+'\n// preserved comment');
  await page.keyboard.press('ControlOrMeta+v');
  await page.click('#musicworkspace [data-action=apply]');
  const applied=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  assert.notEqual(applied.validated.id,initial.validated.id);
  assert.deepEqual(applied.validated.compiled.gb,initial.validated.compiled.gb,'comment edit is lossless');
  await page.click('#musicworkspace [data-action=undo]');
  assert.equal((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).draft,initial.draft,'revision undo restores exact source');
  await page.click('#musicworkspace [data-action=redo]');
  assert((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).draft.endsWith('// preserved comment'));
  await page.click('#musicworkspace .mw-notes');
  await page.locator('#musicworkspace .mw-note').first().click();
  await page.waitForFunction(()=>getSelection().toString().length>0);
  assert(await page.locator('.mw-notes').isVisible()&&await page.locator('.cm-content').isVisible(),'note selects source with both panes visible');
  await page.click('#musicworkspace [data-action=play]');
  await page.waitForFunction(()=>CT_MUSIC_WORKSPACE.snapshot().playing!==null);
  assert.match(await page.locator('.mw-position').textContent(),/Sounding r\d/,'playing waits for engine acknowledgment');
  const sounding=(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).playing;
  await page.waitForTimeout(700); // Include actual periodic position notifications.
  await page.locator('.cm-content').press('ControlOrMeta+End');
  await page.keyboard.insertText('\n// live boundary edit');
  await page.click('#musicworkspace [data-action=apply]');
  const live=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  assert.notEqual(live.validated.id,sounding);
  assert(live.pending||live.playing===live.validated.id,'live Apply queues or acknowledges, never silently remains stopped');
  await page.waitForFunction(()=>{const s=CT_MUSIC_WORKSPACE.snapshot();return s.playing===s.validated.id;});
  await page.click('#musicworkspace [data-action=undo]');
  await page.waitForFunction(id=>CT_MUSIC_WORKSPACE.snapshot().playing===id,sounding);
  await page.evaluate(()=>Audio.audioCtx().suspend());
  await page.waitForFunction(()=>document.querySelector('.mw-state').textContent.includes('audio suspended'));
  await page.click('#musicworkspace [data-action=redo]');
  await page.waitForTimeout(250);
  assert.equal((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).playing,sounding,'suspended audio cannot acknowledge an activation');
  assert((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).pending);
  await page.evaluate(()=>Audio.audioCtx().resume());
  await page.waitForFunction(()=>{const s=CT_MUSIC_WORKSPACE.snapshot();return s.playing===s.validated.id;});
  await page.click('#musicworkspace [data-action=pause]');
  await page.waitForFunction(()=>document.querySelector('.mw-state').textContent.endsWith('paused'));
  await page.click('#musicworkspace [data-action=undo]');
  assert((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).pending,'paused Apply stays queued');
  await page.click('#musicworkspace [data-action=stop]');
  await page.waitForFunction(()=>CT_MUSIC_WORKSPACE.snapshot().playing===null);
  const beforeSpace=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().playing);
  await page.locator('.mcui textarea').fill('hello ');
  await page.locator('.mcui textarea').press('Space');
  assert.equal((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).playing,beforeSpace,'typing Space never plays');
  await page.screenshot({path:path.join(tmp,'desktop.png')});
  await page.setViewportSize({width:390,height:844});
  await page.click('#musicworkspace [data-action=toggle-chat]');
  assert(await page.locator('.mcui textarea').isVisible(),'mobile chat drawer is reachable');
  assert.equal(await page.locator('.mw-main').isVisible(),true,'mobile drawer preserves composition underneath');
  await page.screenshot({path:path.join(tmp,'phone.png')});
  await page.setViewportSize({width:1800,height:900});
  await page.click('#musicworkspace .cm-content');
  const small='song({tempo:128,bars:4})\n'+
    'instruments([[128,240,0,0]]);\n'+
    'event({ch:0,frame:0,frames:60,midi:60,inst:0,vel:1});\n'+
    'event({ch:3,frame:12,frames:4,midi:40,inst:0,vel:1});\n'+
    'event({ch:3,frame:36,frames:4,midi:40,inst:0,vel:1});\n';
  await page.locator('.cm-content').press('ControlOrMeta+a');await page.keyboard.insertText(small);
  await page.click('#musicworkspace [data-action=apply]');
  // Test-only response fixture: verifies proposal plumbing, not a real model.
  await page.route('**/api/music/chat',async route=>{
    assert.equal(route.request().headers()['x-music-provider'],'openai');
    const c=route.request().postDataJSON(),from=c.source.lastIndexOf('event('),to=c.source.indexOf(';',from)+1;
    assert.deepEqual(c.constraints.scope,{tracks:[3]});
    assert(c.constraints.locks.some(l=>l.type==='track'&&l.tracks[0]===0));
    await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({id:c.id,baseRevision:c.baseRevision,edits:[{from,to,text:''}],explanation:'Suggested removal of one drum hit.'})});
  });
  await page.locator('.mcui textarea').fill('simplify the drums, keep the melody');
  await page.waitForFunction(()=>document.querySelector('.mcui-status').textContent.startsWith('Unlocked.'));
  await page.click('#musicworkspace .mcui button[type=submit]');
  await page.waitForFunction(()=>document.querySelector('.mcui-proposal b')?.textContent==='ready');
  await page.getByRole('button',{name:'Apply',exact:true}).click();
  const proposed=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  assert.equal(proposed.validated.compiled.gb.notes.length,2);
  assert.equal(proposed.validated.compiled.gb.notes[0].midi,60);
  await page.click('#musicworkspace [data-action=undo]');
  assert.equal((await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).draft,small,'proposal is one undoable transaction');
  const shared=await page.evaluate(()=>{
    const s=CT_MUSIC_WORKSPACE.snapshot();
    const p=CT_MUSIC_PROJECT.create(s.draft,{compile:CT_MUSIC_LANGUAGE.compile,assetsVersion:CT_MUSIC_ASSETS_VERSION,provenance:{private:'excluded'}});
    return p.serialize();
  });
  assert(!shared.includes('excluded'));
  const sharedPage=await browser.newPage();
  await fixtureChatAccess(sharedPage);
  await sharedPage.goto('http://127.0.0.1:'+server.address().port+'/create#music='+encodeURIComponent(Buffer.from(shared).toString('base64')));
  await sharedPage.waitForSelector('#musicworkspace:not([hidden])');
  assert.equal((await sharedPage.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).draft,small,'shared project route opens exact source');
  assert.equal((await sharedPage.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot())).playing,null,'share has no autoplay');
  await sharedPage.close();
  await page.waitForTimeout(400);
  const other=await page.context().newPage();
  await other.goto('http://127.0.0.1:'+server.address().port+'/create#music');
  await other.waitForSelector('#musicworkspace:not([hidden])');
  await page.locator('.cm-content').press('ControlOrMeta+End');await page.keyboard.insertText('\n// first tab owns this change');
  await page.waitForTimeout(400);
  await other.waitForFunction(()=>document.querySelector('.mw-status').textContent.includes('Another tab changed'));
  await other.click('#musicworkspace .cm-content');
  await other.locator('.cm-content').press('ControlOrMeta+End');await other.keyboard.insertText('\n// conflicting second tab');
  await other.locator('.mw-project-tools>summary').click();
  await other.click('#musicworkspace [data-action=save]');
  assert((await other.evaluate(()=>JSON.parse(localStorage.getItem('ct-music-workspace-v1')).draft)).endsWith('// first tab owns this change'),'conflicting tab never overwrites saved source');
  await other.close();
  await page.evaluate(()=>{
    const handback=window._closeCreateReturn;window.workspaceHandbacks=[];window.workspaceStationPlays=0;
    window._closeCreateReturn=function(options){workspaceHandbacks.push(structuredClone(options));return handback.call(this,options);};
    const playScore=Audio.playScore;
    Audio.playScore=function(...args){workspaceStationPlays++;return playScore.apply(this,args);};
    CT_MUSIC_WORKSPACE.close();
  });
  assert.deepEqual(await page.evaluate(()=>workspaceHandbacks),[{}],'plain close invokes runtime cleanup without Listen authority');
  assert.equal(await page.evaluate(()=>workspaceStationPlays),0,'plain close does not start station playback');
  assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.isOpen()),false,'plain close releases workspace UI');
  await page.evaluate(()=>CT_MUSIC_WORKSPACE.open());
  assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().playing),null,'reopening remains stopped');
  await page.click('#musicworkspace [data-action=listen]');
  assert.deepEqual(await page.evaluate(()=>workspaceHandbacks),[{}, {listen:true}],'Listen explicitly requests station handback');
  assert.equal(await page.evaluate(()=>workspaceStationPlays),1,'Listen explicitly starts station playback once');
  await page.waitForFunction(()=>Audio.chipDiag().owner==='radio');
  await page.waitForFunction(()=>window.__rrrChip&&window.__rrrChip.peak>0.001);
  assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.isOpen()),false,'Listen releases workspace ownership');
  assert.deepEqual(errors,[],'no runtime errors');
  console.log('workspace: integration passed; screenshots '+tmp);
 }catch(error){
  const p=browser.contexts()[0]?.pages()[0];
  if(p)console.error('workspace failure context',await p.evaluate(()=>({url:location.pathname,status:document.querySelector('.mw-status')?.textContent,legacyHint:document.querySelector('.cr-hint')?.textContent,open:globalThis.CT_MUSIC_WORKSPACE?.isOpen(),editor:!!globalThis.CT_MUSIC_CODE_EDITOR})).catch(()=>({unresponsive:true})));
  throw error;
 }finally{await browser.close();}
}
run().then(()=>server.close()).catch(e=>{console.error(String(e).slice(-1500));server.close();process.exitCode=1;});
