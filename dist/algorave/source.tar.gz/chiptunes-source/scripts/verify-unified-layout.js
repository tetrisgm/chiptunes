'use strict';
// Source-loaded Chromium fixtures, using the existing CodeMirror artifact.
// No build, real provider request, credentials, or native Safari claims.
const assert=require('node:assert/strict'),path=require('node:path');
const fs=require('node:fs');
const {chromium}=require('playwright');
(async()=>{
  const browser=await chromium.launch({headless:true});
  try{
    const page=await browser.newPage({viewport:{width:1800,height:1000}});
    await page.context().setOffline(true);
    await page.route('**/*',route=>{
      const pathname=new URL(route.request().url()).pathname;
      if(pathname==='/create')return route.fulfill({contentType:'text/html',body:'<!doctype html><body></body>'});
      if(['/lib/music-preview-worker.js','/lib/gb-hardware.js','/lib/gb-kits.js','/lib/music-language.js'].includes(pathname))
        return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.resolve('src',path.basename(pathname)))});
      return route.abort();
    });
    await page.goto((process.env.SITE_ORIGIN||'https://chiptunes.app')+'/create');
    for(const file of ['gb-hardware.js','music-language.js','music-project.js','music-chat.js','music-preview.js','music-chart-index.js'])await page.addScriptTag({path:path.resolve('src',file)});
    await page.addScriptTag({path:path.resolve('dist/lib/music-code-editor.js')});
    const chatBundle=require('esbuild').buildSync({entryPoints:['src/music-chat-ui.jsx'],bundle:true,write:false,format:'iife',globalName:'CT_MUSIC_CHAT_UI',define:{'process.env.NODE_ENV':'"production"'}});
    await page.addScriptTag({content:chatBundle.outputFiles[0].text});
    await page.evaluate(()=>{
      window.Audio={musicStop(){},enterCreate(){},onMusicState(){return ()=>{};}};window.CT_CREATE={};
      window.fixture={calls:0,finish:null,mounts:0,unmounts:0,sceneCalls:[],returns:[]};
      window._closeCreateReturn=options=>fixture.returns.push(structuredClone(options));
      const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;canvas.style.cssText='width:100%;height:100%;object-fit:contain';
      fixture.canvas=canvas;
      let host=null,scene='maze',enabled=true;
      window.CT_CREATE_PRESENTATION={
        mount(target){fixture.mounts++;host=target;host.append(canvas);},
        unmount(){fixture.unmounts++;canvas.remove();host=null;},
        snapshot(){return {mounted:!!host,enabled,scene,scenes:[{id:'maze',label:'Maze'},{id:'blocks',label:'Blocks'}],width:canvas.width,height:canvas.height};},
        setScene(id){fixture.sceneCalls.push(id);enabled=id!=='off';if(enabled)scene=id;}
      };
      window.fetch=async(url,o)=>{
        if(url==='/api/music/chat/access')return new Response(JSON.stringify({ok:true,authenticated:true,providers:[{id:'openai',label:'OpenAI'}],limits:{dailyCalls:20}}));
        if(url!=='/api/music/chat')throw Error('Unexpected fixture endpoint');
        fixture.calls++;const body=JSON.parse(o.body);
        return new Promise(resolve=>{fixture.finish=()=>resolve(new Response(JSON.stringify({id:body.id,baseRevision:body.baseRevision,edits:[],explanation:'Your source is unchanged.'})));});
      };
    });
    await page.addScriptTag({path:path.resolve('src/music-workspace.js')});
    await page.addStyleTag({path:path.resolve('src/music-workspace.css')});
    await page.addStyleTag({path:path.resolve('src/music-chat-ui.css')});
    await page.evaluate(()=>CT_MUSIC_WORKSPACE.open());
    await page.waitForFunction(()=>document.querySelector('.mcui-status').textContent.startsWith('Unlocked.'));
    const chart=page.locator('.mw-notes'),code=page.locator('.mw-code'),splitter=page.locator('.mw-splitter'),toggle=page.locator('[data-action=toggle-chat]');
    assert.equal(await page.locator('[role=tab],[role=tablist],[role=tabpanel]').count(),0,'no obsolete tab semantics');
    async function stacked(){
      assert(await chart.isVisible());assert(await code.isVisible());
      const a=await chart.boundingBox(),b=await code.boundingBox();
      assert(a.height>=120&&b.height>=160&&a.y+a.height<=b.y,'substantial independent chart above code');
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'no page-wide horizontal overflow');
    }
    await stacked();
    const stage=page.locator('.mw-stage-viewport');
    assert.equal(await page.locator('#musicworkspace').getAttribute('data-presentation'),'composition');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.isVisualizerOpen()),false,'persistent stage is not focus mode');
    assert(await stage.isVisible());assert.equal(await page.locator('.mw-creative > .mw-main,.mw-creative > .mw-stage-splitter,.mw-creative > .mw-visuals').count(),3);
    async function sameStage(){assert.deepEqual(await page.evaluate(()=>({same:document.querySelector('.mw-stage-viewport canvas')===fixture.canvas,width:fixture.canvas.width,height:fixture.canvas.height,mounts:fixture.mounts,unmounts:fixture.unmounts})),{same:true,width:640,height:360,mounts:1,unmounts:0},'layout retains mounted canvas and fixed fixture backbuffer');}
    await sameStage();
    const stageSplitter=page.locator('.mw-stage-splitter');
    assert.equal(await stageSplitter.getAttribute('aria-orientation'),'vertical');
    await stageSplitter.focus();await stageSplitter.press('Home');assert.equal(await stageSplitter.getAttribute('aria-valuenow'),'45');
    await stageSplitter.press('End');assert.equal(await stageSplitter.getAttribute('aria-valuenow'),'75');
    await stageSplitter.press('ArrowLeft');assert(+(await stageSplitter.getAttribute('aria-valuenow'))<75,'stage divider is keyboard adjustable');
    await stageSplitter.press('Home');await stageSplitter.press('ArrowRight');await sameStage();
    await page.locator('.mw-scene').selectOption('off');assert.match(await page.locator('.mw-stage-status').textContent(),/Visuals off/);
    await page.locator('.mw-scene').selectOption('blocks');await sameStage();
    await page.evaluate(()=>{document.querySelector('.mw-stage-viewport').requestFullscreen=function(){fixture.fullscreenTarget=this;return Promise.resolve();};});
    await page.locator('[data-action=stage-fullscreen]').click();assert.equal(await page.evaluate(()=>fixture.fullscreenTarget===document.querySelector('.mw-stage-viewport')),true,'fullscreen targets stage only');
    if(process.env.VERIFY_SCREENSHOT)await page.screenshot({path:process.env.VERIFY_SCREENSHOT});
    const original=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().draft);
    await page.locator('.mw-note').first().click();
    await page.waitForFunction(()=>getSelection().toString().length>0);
    assert(await chart.isVisible(),'note selection never hides chart');
    const selected=await page.evaluate(()=>CT_MUSIC_WORKSPACE.agentContext().policy.selection);
    await page.waitForFunction(()=>document.querySelector('.mw-source-selected'));
    await page.locator('.cm-content').focus();await page.keyboard.press('ControlOrMeta+a');
    assert.equal(await page.locator('.mw-source-selected').count(),await page.locator('.mw-note').count(),'source selection highlights mapped events');
    assert.deepEqual(await page.evaluate(()=>CT_MUSIC_WORKSPACE.agentContext().policy.selection),selected,'cursor selection does not change agent scope');
    await page.locator('.cm-content').fill('// local edit\n'+original);
    await page.locator('.mw-note').first().click();
    assert((await page.locator('.mw-selection').textContent()).includes('Source navigation unavailable'));
    assert.equal(await page.evaluate(()=>getSelection().toString().length),0,'stale mapping does not select source');
    await page.locator('.cm-content').focus();await page.keyboard.press('ControlOrMeta+z');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().draft),original,'editor typing undo preserved');
    await chart.evaluate(el=>{el.firstElementChild.style.minHeight='1000px';el.scrollTop=140;});
    await splitter.focus();await splitter.press('ArrowDown');
    assert.equal(await splitter.getAttribute('aria-valuenow'),'60');
    await splitter.press('Home');assert.equal(await splitter.getAttribute('aria-valuenow'),'20');
    await splitter.press('End');assert.equal(await splitter.getAttribute('aria-valuenow'),'75');
    await splitter.press('ArrowUp');assert.equal(await splitter.getAttribute('aria-valuenow'),'70');
    const handle=await splitter.boundingBox(),surface=await page.locator('.mw-composition').boundingBox();
    await page.mouse.move(handle.x+handle.width/2,handle.y+handle.height/2);await page.mouse.down();
    await page.mouse.move(handle.x+handle.width/2,surface.y+surface.height*.45);await page.mouse.up();
    assert(Math.abs(+(await splitter.getAttribute('aria-valuenow'))-45)<=1,'pointer resizes divider');
    assert.equal(await chart.evaluate(el=>el.scrollTop),140,'resize keeps chart scroll');
    await chart.evaluate(el=>{el.firstElementChild.style.minHeight='';});
    const width=(await page.locator('.mw-main').boundingBox()).width;
    await page.locator('.mcui textarea').fill('Keep this unsent message');
    await toggle.click();assert.equal(await page.locator('.mw-chat').isVisible(),false);
    assert((await page.locator('.mw-main').boundingBox()).width>width,'collapse returns sidebar width');
    assert.equal(await toggle.getAttribute('aria-expanded'),'false');
    await toggle.click();assert.equal(await page.locator('.mcui textarea').inputValue(),'Keep this unsent message');
    assert.equal(await page.evaluate(()=>document.activeElement.tagName),'TEXTAREA','restore focuses retained composer');
    const revision=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().validated.id);
    await page.getByRole('button',{name:'Send',exact:true}).click();await page.waitForFunction(()=>fixture.calls===1);
    const request=await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().request.id);
    await toggle.click();
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().request.id),request,'collapse does not cancel request');
    await page.locator('[data-action=visualizer]').click();
    assert.equal(await code.isVisible(),false,'visualizer hides but keeps composition mounted');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.isVisualizerOpen()),true);await sameStage();
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().request.id),request,'visualizer keeps in-flight request');
    await page.locator('[data-action=visualizer]').click();assert(await code.isVisible());
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.isVisualizerOpen()),false);await sameStage();
    assert.deepEqual(await page.evaluate(()=>fixture.sceneCalls),['off','blocks'],'focus layout never calls scene adapter');
    await page.evaluate(()=>fixture.finish());
    await page.waitForFunction(()=>CT_MUSIC_WORKSPACE.snapshot().request===null);
    await toggle.click();assert((await page.locator('.mcui-content').textContent()).includes('Your source is unchanged.'));
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().validated.id),revision,'collapse/reply never applies or plays');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().playing),null);
    assert.deepEqual(await page.evaluate(()=>CT_MUSIC_WORKSPACE.agentContext().policy.selection),selected);
    await page.setViewportSize({width:1280,height:900});
    await page.waitForFunction(()=>document.querySelector('.mw-chat').hidden);
    await stacked();await sameStage();
    const drawerGeometry=await page.evaluate(()=>['.mw-main','.mw-stage-viewport'].map(s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};}));
    await toggle.click();assert(await page.locator('.mw-chat').isVisible(),'1280 uses an overlay drawer');
    assert.deepEqual(await page.evaluate(()=>['.mw-main','.mw-stage-viewport'].map(s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};})),drawerGeometry,'1280 drawer preserves music and stage geometry');
    await sameStage();await toggle.click();
    await page.setViewportSize({width:390,height:844});
    await page.waitForFunction(()=>document.querySelector('.mw-chat').hidden);
    await stacked();
    assert.equal(await page.evaluate(()=>document.activeElement.dataset.action),'toggle-chat','mobile collapse safely returns focus');
    await toggle.click();assert.equal(await page.locator('.mw-chat').isVisible(),true,'mobile drawer opens');
    assert.equal(await page.locator('.mw-main').isVisible(),true,'drawer does not replace composition');
    await page.locator('.mcui textarea').fill('Mobile draft');await page.locator('.mcui').getByRole('button',{name:'Hide chat',exact:true}).click();
    assert.equal(await page.evaluate(()=>document.activeElement.dataset.action),'toggle-chat');
    await toggle.click();assert.equal(await page.locator('.mcui textarea').inputValue(),'Mobile draft');
    await page.setViewportSize({width:1800,height:1000});await stacked();await sameStage();
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().draft),original);
    assert.equal(await page.evaluate(()=>fixture.calls),1,'layout never calls a provider');
    await page.locator('.cm-content').fill(original.replace('C4 . E4','D4 . E4'));
    await page.waitForFunction(()=>document.querySelector('.mw-chart-status').textContent==='Draft preview · not applied');
    assert((await page.locator('.mw-note').allTextContents()).includes('D4'),'draft pitch changes chart');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().validated.source),original,'preview does not install a revision');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().playing),null,'preview does not play');
    await page.locator('.cm-content').fill('invalid(');
    await page.waitForFunction(()=>document.querySelector('.mw-chart-status').textContent==='Previous chart · draft has errors');
    assert((await page.locator('.mw-note').allTextContents()).includes('D4'),'invalid preview retains last chart');
    const dense='song({tempo:128,bars:256})\npattern("dense", notes("'+Array(16).fill('C4').join(' ')+'").stepsPerBar(16).gate(0.5))\n'+
      [['lead','p0'],['pad','p1'],['bass','wave-bass'],['drums','n-tick']].map(([track,instrument])=>'track('+JSON.stringify(track)+').instrument('+JSON.stringify(instrument)+').play("dense", {repeat:256})').join('\n');
    await page.locator('.cm-content').fill(dense);
    await page.waitForFunction(()=>document.querySelector('.mw-note-group'));
    assert(await page.locator('.mw-note,.mw-note-group').count()<=400,'dense chart bounds mounted nodes');
    assert((await page.locator('.mw-chart-status').textContent()).includes('counted groups'),'aggregation is disclosed');
    await page.locator('.mw-note-group').first().click();
    assert(await page.locator('.mw-chart-reset').isVisible(),'dense group can be inspected');
    assert(await page.locator('.mw-note').count()>0,'narrowing exposes exact note events');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().validated.source),original,'dense preview does not apply');
    await page.locator('.mw-chart-reset').click();
    assert(await page.locator('.mw-note-group').count()>0,'full-song overview restores bounded groups');
    await page.locator('.cm-content').fill(original);
    await page.waitForFunction(()=>document.querySelector('.mw-chart-status').textContent==='Validated chart');
    await page.locator('.mw-project-tools>summary').click();assert(await page.locator('[data-action=save]').isVisible(),'secondary tools remain reachable');
    await page.locator('[data-action=save]').click();
    await page.waitForFunction(source=>JSON.parse(localStorage.getItem('ct-music-workspace-v1')||'{}').draft===source,original);
    const stored=await page.evaluate(()=>JSON.stringify({...localStorage}));
    const imported='// explicit shared copy\n'+original;
    await page.evaluate(source=>CT_MUSIC_WORKSPACE.open({source,explicit:true}),imported);
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().draft),imported,'explicit source replaces in-memory project');
    assert.equal((await page.locator('.cm-line').allTextContents()).join('\n'),imported,'editor reflects explicit source');
    assert.equal(await page.evaluate(()=>JSON.stringify({...localStorage})),stored,'explicit source never overwrites recovery');
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().playing),null,'import never plays');
    await assert.rejects(page.evaluate(()=>CT_MUSIC_WORKSPACE.open({source:'invalid(',explicit:true})),/invalid/);
    assert.equal(await page.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().draft),imported,'invalid import preserves current draft');
    await page.evaluate(()=>CT_MUSIC_WORKSPACE.close());
    assert.deepEqual(await page.evaluate(()=>fixture.returns),[{}],'plain close requests cleanup without station playback');
    assert.equal(await page.evaluate(()=>fixture.unmounts),1,'close releases the stage');
    await page.evaluate(()=>CT_MUSIC_WORKSPACE.open());await page.locator('[data-action=listen]').click();
    assert.deepEqual(await page.evaluate(()=>fixture.returns),[{}, {listen:true}],'Listen explicitly requests station playback after cleanup');
    console.log('PASS unified layout: persistent stage and fixed fixture canvas, desktop sidebar/1280/mobile drawers, keyboard/pointer splitters, exact/stale mapping, typing undo, chart scroll, in-flight chat, explicit Listen, no incidental autoplay/provider calls');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
