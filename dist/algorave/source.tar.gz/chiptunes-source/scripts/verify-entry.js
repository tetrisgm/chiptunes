// Nothing plays until you ask for it.
//
// A cold load holds: the station writes nothing until a mood is picked, the
// play button is pressed. Song links now open silent unified composition.
// This is easy to break from a
// distance, and it did break -- "tap anywhere to start the music" was still
// wired to the whole page, and once holding correctly reported as PAUSED (it
// is: nothing is playing) that handler read every stray click as "resume" and
// started a mood at random. A visitor who clicked the background got music
// they had not asked for.
//
// So this checks both halves: a click that means nothing starts nothing, and
// the two things that DO mean something still work.
'use strict';
const fs = require('fs');
const http = require('http');
const path = require('path');
const { chromium } = require('playwright');

const DIST = path.join(__dirname, '..', 'dist');
const wait = ms => new Promise(r => setTimeout(r, ms));
let fail = 0;
const ok = (c, m) => { console.log((c ? '  ok   ' : '  FAIL ') + m); if (!c) fail++; };

function server() {
  return new Promise(res => {
    const s = http.createServer((q, e) => {
      let rel = decodeURIComponent(new URL(q.url, 'http://x').pathname).replace(/^\/+/, '');
      let f = path.join(DIST, rel || 'index.html');
      if (!f.startsWith(DIST) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(DIST, 'index.html');
      fs.readFile(f, (err, b) => {
        if (err) { e.writeHead(500); e.end(); return; }
        e.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : 'text/html' });
        e.end(b);
      });
    });
    s.listen(0, '127.0.0.1', () => res({ s, port: s.address().port }));
  });
}
const peak = async (p, ms) => {
  let k = 0;
  for (let i = 0; i < Math.ceil(ms / 200); i++) {
    k = Math.max(k, await p.evaluate(() => Audio.outputProbe().peak));
    await wait(200);
  }
  return k;
};
// ASSERTING THAT SOMETHING BECOMES AUDIBLE IS A RACE, and a fixed window loses
// it occasionally: a track has to compose, the deck opens 0.18s in the future,
// and the output ramps. Measured, this assertion failed about one run in nine
// against a 3.5s wait plus a 3s sample. Waiting UNTIL it is audible, with a
// generous ceiling, is fast when it works and patient when the machine is busy.
// Absence still has to be sampled over a full window -- use peak() for that.
const audibleWithin = async (p, ms, threshold = 0.02) => {
  let k = 0;
  for (let i = 0; i < Math.ceil(ms / 200); i++) {
    k = Math.max(k, await p.evaluate(() => Audio.outputProbe().peak));
    if (k > threshold) return k;
    await wait(200);
  }
  return k;
};

(async () => {
  const h = await server();
  const b = await chromium.launch({ headless: true, args: ['--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 1500, height: 950 } });
  const errs = [];
  p.on('pageerror', e => errs.push(String(e).slice(0, 120)));
  await p.goto(`http://127.0.0.1:${h.port}/listen`, { waitUntil: 'domcontentloaded' });
  await wait(4000);

  ok(await p.evaluate(() => !!(Audio.isHolding && Audio.isHolding())), 'a cold load holds');
  ok(await p.evaluate(() => document.body.classList.contains('awaiting-mood')),
     'and says so: the moods are the only thing on offer');
  ok((await peak(p, 2500)) < 0.02, 'nothing is sounding');
  // ...and nothing tells you to just listen, either. That hint is for somebody
  // watching a game; on the home it lands over the buttons that would give them
  // something to listen to.
  await p.keyboard.press('KeyX');
  await p.mouse.click(700, 300);
  await wait(900);
  const shouted = await p.evaluate(() => {
    const t = [...document.querySelectorAll('*')]
      .filter(e => /toast/i.test(String(e.className)) && e.getClientRects().length)
      .map(e => e.textContent.trim()).filter(Boolean);
    return t.join(' | ');
  });
  ok(!/background radio/i.test(shouted),
     'and nothing says "this is a background radio" before there is one' +
     (shouted ? ' -- saw: ' + shouted.slice(0, 60) : ''));
  ok(await p.evaluate(() => { const b2 = document.getElementById('pbPlay'); return b2 && b2.dataset.icon === 'play'; }),
     'the transport offers PLAY, not pause');

  // Clicks that mean nothing must start nothing. Address the inert surfaces by
  // role: fixed viewport coordinates become controls as the landing Game Boy
  // and player bar move between layouts.
  const checkInert = async (what, click) => {
    await click();
    await wait(1200);
    const q = await peak(p, 1500);
    const held = await p.evaluate(() => !!(Audio.isHolding && Audio.isHolding()));
    ok(q < 0.02 && held, 'clicking ' + what + ' starts nothing (' + q.toFixed(3) + ')');
  };
  const inertTargets = [
    ['#stage', 'pointerdown', 'the game scene'],
    ['.rmood-brand', 'click', 'the landing screen'],
    ['#playbar', 'click', 'the player-bar background'],
    ['.pb-lcd-head', 'click', 'the track header around its title']
  ];
  for (const [selector, type, what] of inertTargets) {
    const exists = await p.evaluate(sel => !!document.querySelector(sel), selector);
    ok(exists, what + ' exists');
    if (exists) await checkInert(what, () => p.evaluate(([sel, eventType]) => {
      const EventType = eventType === 'pointerdown' ? PointerEvent : MouseEvent;
      document.querySelector(sel).dispatchEvent(new EventType(eventType, {
        bubbles: true, cancelable: true, pointerId: 1, pointerType: 'mouse'
      }));
    }, [selector, type]));
  }

  // ...and the two things that DO mean something still work
  await p.evaluate(() => { document.getElementById('pbPlay').click(); });
  await wait(3500);
  // Every control that can be picked by "surprise me" must actually start a
  // song. `.rmood` is a look, not a meaning: Start from scratch, How it works
  // and Make it all wear it.
  const pickable = await p.evaluate(() => {
    const sel = [...document.querySelectorAll('#rmoods .rmood[data-mood]')];
    const all = [...document.querySelectorAll('#rmoods .rmood')];
    return { moods: sel.map(e => e.dataset.mood),
             nonMoods: all.filter(e => !e.dataset.mood).map(e => e.textContent.trim()) };
  });
  ok(pickable.moods.length >= 3 && pickable.moods.every(Boolean),
     '"surprise me" can only pick real moods (' + pickable.moods.join(', ') + ')');
  ok(pickable.nonMoods.length > 0,
     'and the row does carry pills that are not moods, which is why that matters (' +
     pickable.nonMoods.join(', ') + ')');
  const playPeak = await audibleWithin(p, 20000);
  ok(playPeak > 0.02, 'pressing play starts one anyway (it means "surprise me") [peak ' + playPeak.toFixed(4) +
     ', chip ' + JSON.stringify(await p.evaluate(() => { try { return Audio.chipDiag ? Audio.chipDiag() : null; } catch (e) { return String(e); } })).slice(0, 160) + ']');

  ok(await p.evaluate(() => location.pathname === '/listen'),
     'playing keeps the explicit listening address');

  await p.goto(`http://127.0.0.1:${h.port}/listen`, { waitUntil: 'domcontentloaded' });
  await wait(4000);
  ok(await p.evaluate(() => location.pathname === '/listen' && document.body.classList.contains('awaiting-mood')),
     'returning to /listen returns to the explicit listening landing page');
  await p.evaluate(() => {
    const C = CT_COMPOSERS.rrr_core;
    const original = C.compile;
    window.__moodCompileCalls = 0;
    C.compile = function () {
      window.__moodCompileCalls++;
      return original.apply(this, arguments);
    };
    // Naturally a trance token. An epic request must constrain this one token
    // to anthem, rather than compiling new tokens until anthem appears.
    Song.mint = () => '523e26qcl13jeeuu';
  });
  await p.evaluate(() => {
    const b2 = [...document.querySelectorAll('.rmood')].find(x => x.textContent === 'epic');
    if (b2) b2.click();
  });
  await p.waitForFunction(() => !document.querySelector('.rmood.busy'), null, { timeout: 25000 });
  await wait(3000);
  ok((await audibleWithin(p, 20000)) > 0.02, 'and picking a mood plays that');
  const moodResult = await p.evaluate(() => {
    const s = CT_CREATE._source();
    return { calls: window.__moodCompileCalls, style: s && s.style,
             premise: s && s.tracker && s.tracker.premise };
  });
  ok(moodResult.calls === 1, 'a mood composes exactly one token (' + moodResult.calls + ' call)');
  ok(moodResult.style === 'anthem' && moodResult.premise &&
     moodResult.premise.styles && moodResult.premise.styles[0] === 'anthem',
     'and that one score records and satisfies the epic premise');
  ok(!(await p.evaluate(() => document.body.classList.contains('awaiting-mood'))),
     'the hero stands down once something is on');
  // Canonical composition entry is not a request to start another player.
  await p.goto(`http://127.0.0.1:${h.port}/listen`, { waitUntil: 'domcontentloaded' });
  await p.locator('.rmood-scratch').click();
  await p.waitForFunction(()=>window.CT_MUSIC_WORKSPACE?.isOpen()&&CT_MUSIC_WORKSPACE.snapshot()?.validated,null,{timeout:30000});
  ok(await p.evaluate(()=>location.pathname==='/create'&&!document.querySelector('#createscreen.show')),
     'Start from scratch enters canonical composition, not legacy editor');
  ok(await p.locator('.mw-notes').isVisible()&&await p.locator('.mw-code').isVisible(),'chart and code are visible together');
  ok((await peak(p,1500))<.02&&await p.evaluate(()=>!CT_MUSIC_WORKSPACE.snapshot().playing&&!CT_MUSIC_WORKSPACE.snapshot().pending),
     'composition opens silently');
  await p.locator('[data-action=play]').click();
  ok((await audibleWithin(p,20000))>.02,'explicit composition Play is audible');
  await p.evaluate(() => {
    window.entryCloseStarts=[];window.entryStopAck=null;
    window.entryStopOff=Audio.onMusicState(state=>{
      if(state.status==='stopped')entryStopAck={wall:performance.now(),context:Audio.audioCtx().currentTime};
    });
    for(const name of ['playScore','playCreate','enterCreate','musicPlay','musicQueue']){
      const original=Audio[name];
      Audio[name]=function(...args){entryCloseStarts.push(name);return original.apply(this,args);};
    }
  });
  await p.locator('[data-action=stop]').click();
  await p.evaluate(() => CT_MUSIC_WORKSPACE.close());
  // outputProbe caches for 100 ms; the analyser also retains 2048 old samples.
  // Wait for the real processor Stop acknowledgement and both old-data windows,
  // then still observe silence for the FULL interval. An immediately cached
  // pre-Stop peak is not evidence of a new player. The command spy separately
  // catches any start/queue request, even if it would not sound until later.
  await p.waitForFunction(()=>entryStopAck&&performance.now()-entryStopAck.wall>100&&
    Audio.audioCtx().currentTime-entryStopAck.context>2048/Audio.audioCtx().sampleRate,null,{timeout:5000});
  const closePeak=await peak(p,1500);
  const closed=await p.evaluate(()=>{
    entryStopOff();return {calls:entryCloseStarts,open:CT_MUSIC_WORKSPACE.isOpen(),status:Audio.musicVisualState()?.status};
  });
  ok(closePeak<.02&&!closed.open&&closed.status==='stopped'&&closed.calls.length===0,
    'plain composition close never starts the station ('+closePeak.toFixed(3)+', starts: '+closed.calls.join(',')+')');

  // The public root is the instrument, not the compatibility listening wall.
  await p.goto(`http://127.0.0.1:${h.port}/`, { waitUntil: 'domcontentloaded' });
  await p.waitForFunction(()=>window.CT_MUSIC_WORKSPACE?.isOpen()&&CT_MUSIC_WORKSPACE.snapshot()?.validated,null,{timeout:30000});
  ok(await p.locator('.mw-code').isVisible()&&await p.locator('.mw-notes').isVisible()&&await p.locator('.mw-stage-viewport').isVisible(),
     'root opens music code, notes and persistent visual stage together');
  ok(await p.evaluate(()=>!CT_CREATE.isOpen()&&!document.body.classList.contains('awaiting-mood')),
     'root has no legacy editor or mood setup wall');
  ok((await peak(p,1500))<.02&&await p.evaluate(()=>!CT_MUSIC_WORKSPACE.snapshot().playing&&!CT_MUSIC_WORKSPACE.snapshot().pending),
     'root restores composition stopped, with no queued player');
  await p.locator('.mw-visuals').getByText('Visuals',{exact:true}).first().click();
  ok((await peak(p,1000))<.02,'interacting with visual chrome never starts music');
  const savedSource=await p.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot().draft);
  await p.reload({waitUntil:'domcontentloaded'});
  await p.waitForFunction(()=>window.CT_MUSIC_WORKSPACE?.isOpen()&&CT_MUSIC_WORKSPACE.snapshot()?.validated,null,{timeout:30000});
  ok(await p.evaluate(source=>CT_MUSIC_WORKSPACE.snapshot().draft===source&&!CT_MUSIC_WORKSPACE.snapshot().playing,savedSource),
     'reload retains the music source without resuming playback');
  await p.keyboard.press('Escape');
  ok(await p.evaluate(()=>CT_MUSIC_WORKSPACE.isOpen()),'Escape retains the primary music workspace');
  ok((await peak(p,1500))<.02,'plain Escape never starts station audio');
  ok(!errs.length, 'no page errors' + (errs.length ? ' -- ' + errs[0] : ''));

  await b.close(); h.s.close();
  console.log(fail ? '\nverify-entry: ' + fail + ' FAILED'
                   : '\nverify-entry: nothing plays until it is asked for');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e.message); process.exit(1); });
