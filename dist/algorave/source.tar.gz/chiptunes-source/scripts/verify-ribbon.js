// The track ribbon: the whole song along the bottom, doubling as the scrubber.
//
// A music player draws a waveform where the progress bar goes. A Game Boy's
// waveform is its notes, and since the station plays a document they are simply
// there to read -- so the strip shows every note of the track at once, what has
// played lit and what is coming dimmed, with the bar lines behind it.
//
// It is drawn by the frame loop, which is the one place in this app where a
// careless full redraw turns into judder, so this also checks it stays cheap:
// the song is baked once per track and blitted twice a frame.
'use strict';
const fs = require('fs');
const http = require('http');
const path = require('path');
const { chromium } = require('playwright');

const DIST = path.join(__dirname, '..', 'dist');
const wait = ms => new Promise(r => setTimeout(r, ms));
let fail = 0;
  // Nothing plays until asked: pick a mood, which is the station's entry now.
  const startStation = async (pg) => {
    await pg.evaluate(() => {
      const b = [...document.querySelectorAll('.rmood')].find(x => x.textContent === 'chill');
      if (b) b.click();
    });
    await pg.waitForFunction(() => !document.querySelector('.rmood.busy'), null, { timeout: 25000 });
    // A baked strip is not evidence that the audio worklet has started. The
    // progress test needs real playback before taking its first pixel sample.
    await pg.waitForFunction(() => Audio.outputProbe().peak > .02, null, { timeout: 25000 });
  };
const ok = (c, m) => { console.log((c ? '  ok   ' : '  FAIL ') + m); if (!c) fail++; };

function server() {
  return new Promise(res => {
    const s = http.createServer((q, e) => {
      let rel = decodeURIComponent(new URL(q.url, 'http://x').pathname).replace(/^\/+/, '');
      let f = path.join(DIST, rel || 'index.html');
      if (!f.startsWith(DIST) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(DIST, 'index.html');
      fs.readFile(f, (err, b) => {
        if (err) { e.writeHead(500); e.end(); return; }
        e.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : 'text/html' });
        e.end(b);
      });
    });
    s.listen(0, '127.0.0.1', () => res({ s, port: s.address().port }));
  });
}
// The unified workspace covers and inerts the station rather than necessarily
// deleting its layout boxes. Check exposed hit surface, not only computed size.
const shown = p => p.evaluate(() => {
  const c = document.getElementById('noteribbon');
  if(!c||!c.getClientRects().length)return false;
  const r=c.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);
  return !!hit&&!!hit.closest('#playbar');
});
const pixels = p => p.evaluate(() => {
  const c = document.getElementById('noteribbon');
  const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  let any = 0, lit = 0;
  for (let i = 0; i < d.length; i += 4) { if (d[i + 3] > 8) { any++; if (d[i + 3] > 140) lit++; } }
  return { any, lit, w: c.width, h: c.height };
});

(async () => {
  const h = await server();
  const b = await chromium.launch({ headless: true, args: ['--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 1600, height: 1000 }, deviceScaleFactor: 2 });
  const errs = [];
  p.on('pageerror', e => errs.push(String(e).slice(0, 120)));
  await p.goto(`http://127.0.0.1:${h.port}/listen`, { waitUntil: 'domcontentloaded' });
  await wait(3500);
  // Rendering/progress coverage uses one known arrangement. Composer diversity
  // is independently tested; this must not race a random silent intro or seam.
  await p.evaluate(() => { Song.mint = () => '523e26qcl13jeeuu'; });
  await startStation(p);
  await wait(7000);

  ok(await shown(p), 'the ribbon is up while the station plays');
  const geo = await p.evaluate(() => {
    const c = document.getElementById('noteribbon'), r = c.getBoundingClientRect();
    const ctrl = document.querySelector('#playbar .pb-ctrl');
    const cr = ctrl ? ctrl.getBoundingClientRect() : null;
    const lcd = document.querySelector('#playbar .pb-lcd');
    const lr = lcd ? lcd.getBoundingClientRect() : null;
    const ttl = document.getElementById('pbTitle');
    const tr = ttl ? ttl.getBoundingClientRect() : null;
    const share = document.getElementById('pbShare');
    const sr = share ? share.getBoundingClientRect() : null;
    const left = document.querySelector('#playbar .pb-left');
    const right = document.querySelector('#playbar .pb-right');
    const ar = left ? left.getBoundingClientRect() : null;
    const rr = right ? right.getBoundingClientRect() : null;
    return { w: Math.round(r.width), h: Math.round(r.height),
             inCtrl: !!(ctrl && ctrl.contains(c)),
             inPanel: !!(lcd && lcd.contains(c)),
             titleAtLeft: !!(tr && ar && tr.left >= ar.left - 1 && tr.right <= ar.right + 1),
             shareByTitle: !!(tr && sr && sr.left >= tr.right && Math.abs((sr.top+sr.bottom-tr.top-tr.bottom)/2)<3),
             panelHolds: !!(lr && r.left >= lr.left - 1 && r.right <= lr.right + 1),
             dockedBetween: !!(cr && ar && rr && cr.left >= ar.right - 1 && cr.right <= rr.left + 1),
             fromBottom: cr ? Math.round(innerHeight - cr.bottom) : -1,
             times: [(document.getElementById('pbElapsed')||{}).textContent,
                     (document.getElementById('pbTotal')||{}).textContent] };
  });
  ok(geo.inCtrl, 'it lives inside the transport group, not floating on its own');
  // the transport moved to the left of the bar (Apple Music's shape); the strip
  // is the scrubber inside the now-playing panel
  ok(geo.inPanel, 'it sits inside the now-playing panel');
  ok(geo.titleAtLeft && geo.shareByTitle, 'the track name and share control sit together at the left');
  ok(geo.panelHolds, 'and the panel contains it rather than being overflowed');
  ok(geo.dockedBetween, 'the docked groups stay in order without overlap');
  ok(geo.fromBottom > 0 && geo.fromBottom < 60, 'and anchored to the bottom (' + geo.fromBottom + 'px up)');
  ok(geo.h > 20 && geo.h < 90, 'the track stays a strip rather than a second view (' + geo.h + 'px tall)');
  ok(/^\d+:\d\d$/.test(geo.times[0] || '') && /^\d+:\d\d$/.test(geo.times[1] || ''),
     'with elapsed and total either side (' + geo.times.join(' / ') + ')');

  // the four voices must be TOLD APART, in the editor's colours -- the first
  // cut mapped every voice into one pitch band and came out 69% drum-purple
  const voices = await p.evaluate(async () => {
    const c = document.getElementById('noteribbon');
    // Wait for a REAL bake. 200 painted pixels is satisfied by the empty strip
    // -- the bar is up from the first paint now, so there is a legitimate state
    // with almost nothing in it, and sampling colours then reads one voice or
    // none. A whole track paints tens of thousands.
    for (let t = 0; t < 60; t++) {
      const q = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
      let n = 0; for (let i = 3; i < q.length; i += 4) if (q[i] > 40) { n++; if (n > 4000) break; }
      if (n > 4000) break;
      await new Promise(r => setTimeout(r, 100));
    }
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const want = [[0x7B,0xDC,0xA0],[0x57,0xC4,0xFF],[0xE8,0xA7,0x5D],[0xC9,0xA4,0xE8]];
    const hit = [0, 0, 0, 0];
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 40) continue;
      let best = -1, bd = 60;
      for (let k = 0; k < 4; k++) {
        const dd = Math.abs(d[i] - want[k][0]) + Math.abs(d[i+1] - want[k][1]) + Math.abs(d[i+2] - want[k][2]);
        if (dd < bd) { bd = dd; best = k; }
      }
      if (best >= 0) hit[best]++;
    }
    const n = Audio.currentScore().gb.notes, per = [0,0,0,0];
    n.forEach(x => per[x.ch | 0]++);
    return { hit, per };
  });
  const sounding = voices.per.filter(x => x > 0).length;
  const drawn = voices.hit.filter(x => x > 20).length;
  ok(drawn >= Math.min(3, sounding),
     'each voice is drawn in its own editor colour (' + drawn + ' of ' + sounding +
     ' sounding voices found: ' + voices.hit.join('/') + ')');
  // THIS IS ABOUT THE DRAWING, NOT THE SONG. The check above is the real one --
  // three or more voices each painted in their own colour. This one exists to
  // catch a ribbon painted entirely in ONE colour, which the counts above could
  // in principle miss.
  //
  // It was set at 75%, which measured the composition rather than the renderer:
  // the station serves a random song, and a legitimately drum-heavy one puts 77%
  // of the lit pixels on the noise voice. That is a real song, not a bug. 90%
  // still catches a strip drawn in a single colour and never fails on a
  // perfectly good arrangement.
  const tot = voices.hit.reduce((a, c) => a + c, 0) || 1;
  ok(Math.max(...voices.hit) / tot < 0.90,
     'and no single voice swamps the strip (' + (100 * Math.max(...voices.hit) / tot).toFixed(0) + '% at most)');

  const a = await pixels(p);
  const notes = await p.evaluate(() => Audio.currentScore().gb.notes.length);
  ok(a.any > 500, 'it has drawn the track (' + notes + ' notes, ' + a.any + ' painted pixels)');
  await wait(7000);
  const c2 = await pixels(p);
  if(c2.lit<=a.lit)console.log('  progress diagnostics '+JSON.stringify(await p.evaluate(()=>({
    elapsed:document.getElementById('pbElapsed').textContent,chip:Audio.chipDiag(),
    processor:window.__rrrChip,holding:Audio.isHolding(),probe:Audio.outputProbe()
  }))));
  ok(c2.lit > a.lit, 'and the played part grows as the song plays (' + a.lit + ' -> ' + c2.lit + ' lit pixels)');
  ok(Math.abs(c2.any - a.any) < a.any * 0.25, 'while the track itself stays put (baked once, not redrawn)');

  // its OWN cost, not the whole frame's -- the frame EMA covers the game and
  // the shaders and is dominated by whatever the software rasteriser is doing
  const rib = await p.evaluate(() => window.__rrrFrame.rib);
  ok(rib < 1.5, 'drawing it costs ' + rib + 'ms a frame (baked once, blitted twice)');

  // The strip opens canonical composition with the exact current document.
  const radioGB=await p.evaluate(()=>JSON.parse(JSON.stringify(Audio.currentScore().gb)));
  await p.evaluate(() => { document.getElementById('noteribbon').click(); });
  await p.waitForFunction(()=>window.CT_MUSIC_WORKSPACE?.isOpen()&&CT_MUSIC_WORKSPACE.snapshot()?.validated,null,{timeout:30000});
  ok(!(await shown(p)), 'the station bar leaves while Create owns the screen');
  const inset = await p.evaluate(() => {
    const cs = document.getElementById('musicworkspace');
    const pb = document.getElementById('playbar');
    if (!cs || !pb) return null;
    const a = cs.getBoundingClientRect(), b2 = pb.getBoundingClientRect();
    const hit=document.elementFromPoint(b2.left+b2.width/2,b2.top+b2.height/2);
    return { top:Math.round(a.top), bottom:Math.round(a.bottom), height:Math.round(a.height), vh:innerHeight,
      dockVisible:!!hit&&!!hit.closest('#playbar'),dockInert:!!pb.closest('[inert]') };
  });
  ok(inset && inset.height >= inset.vh*.9 && inset.top === 0 && Math.abs(inset.bottom-inset.vh)<2,
     'unified composition fills the viewport');
  ok(inset && !inset.dockVisible&&inset.dockInert, 'station transport is covered and excluded from keyboard interaction');
  const opened=await p.evaluate(()=>CT_MUSIC_WORKSPACE.snapshot());
  ok(require('node:util').isDeepStrictEqual(opened.validated.compiled.gb,radioGB),'ribbon entry preserves the entire radio score');
  ok(opened.playing===null&&opened.pending===null,'opening composition does not start workspace playback');
  ok(await p.locator('.mw-notes').isVisible()&&await p.locator('.mw-code').isVisible(),'chart and source are visible together');
  await p.getByRole('button',{name:'Listen',exact:true}).click();
  await wait(4000);
  ok(await shown(p), 'and comes back on explicit Listen');
  ok(await p.evaluate(()=>location.pathname==='/listen'),'Listen keeps the listening route');
  ok(!errs.length, 'no page errors' + (errs.length ? ' -- ' + errs[0] : ''));

  await b.close(); h.s.close();
  console.log(fail ? '\nverify-ribbon: ' + fail + ' FAILED'
                   : '\nverify-ribbon: the whole track reads along the bottom');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e.message); process.exit(1); });
