const setTimeout = (a, b) => {};
